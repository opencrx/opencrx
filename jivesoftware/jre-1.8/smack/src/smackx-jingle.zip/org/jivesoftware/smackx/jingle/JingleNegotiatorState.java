package org.jivesoftware.smackx.jingle;

/**
 *  @author Jeff Williams
 */
public enum JingleNegotiatorState {
    PENDING,
    FAILED,
    SUCCEEDED
}
