package org.openqa.selenium.remote.http;

public enum HttpMethod {
  DELETE,
  GET,
  POST
}
